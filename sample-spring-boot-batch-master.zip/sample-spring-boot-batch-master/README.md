# sample-spring-boot-batch

## Sample Spring Batch using JPA and Spring Boot

###The project requires with 2 databases :
- sample
- tech

###Unit Test do use :
- H2 embedded database

###Main program do use :
- Postgresql database(s) running on localhost

