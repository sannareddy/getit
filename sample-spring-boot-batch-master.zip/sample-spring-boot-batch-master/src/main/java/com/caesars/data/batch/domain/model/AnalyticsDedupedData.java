package com.caesars.data.batch.domain.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity(name="ANALYTICS_DEDUPED")
public class AnalyticsDedupedData {

	@Id
	@GeneratedValue
	private Long id;

	@Column(name = "trnumber")
	private String trNumber;
	
	@Column(name = "badgename")
	private String badgeName;
	
	@Column(name = "promoname")
	private String promoName;
	
	@Column(name = "expires")
	private Timestamp expires;
	
	@Column(name="d_created_timestamp")
	private Timestamp dCreatedTimestamp;
	
	public AnalyticsDedupedData() {
	}

	public AnalyticsDedupedData(String trNumber, String badgeName,String promoName,Timestamp expires,Timestamp dCreatedTimestamp) {
		this.trNumber=trNumber;
		this.badgeName=badgeName;
		this.promoName = promoName;
		this.expires = expires;
		this.dCreatedTimestamp=dCreatedTimestamp;
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getTrNumber() {
		return trNumber;
	}

	public void setTrNumber(String trNumber) {
		this.trNumber = trNumber;
	}

	public String getBadgeName() {
		return badgeName;
	}

	public void setBadgeName(String badgeName) {
		this.badgeName = badgeName;
	}

	public String getPromoName() {
		return promoName;
	}

	public void setPromoName(String promoName) {
		this.promoName = promoName;
	}

	public Timestamp getExpires() {
		return expires;
	}

	public void setExpires(Timestamp expires) {
		this.expires = expires;
	}
	
	
	public Timestamp getdCreatedTimestamp() {
		return dCreatedTimestamp;
	}

	public void setdCreatedTimestamp(Timestamp dCreatedTimestamp) {
		this.dCreatedTimestamp = dCreatedTimestamp;
	}

	@Override
	public String toString() {
		return "id: " + id + ", trnumber: " + trNumber + ", badgeName: " + badgeName + ", promoName: " + promoName
				+ ", expires:" + expires+", dCreatedTimestamp: "+dCreatedTimestamp;
	}
}
