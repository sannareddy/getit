package com.caesars.data.batch.domain.repo;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class AnalyticsDataRepoService {

	@Autowired
	private AnalyticsDataRepository analyticsDataRepository;
	
	//Implementation of custom methods of AnalyticsDataRepository interface should go here...
}
