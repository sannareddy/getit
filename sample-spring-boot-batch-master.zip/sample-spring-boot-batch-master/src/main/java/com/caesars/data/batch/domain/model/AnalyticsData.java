package com.caesars.data.batch.domain.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity(name="ANALYTICS_DATA")
public class AnalyticsData {

	@Id
	@GeneratedValue
	private Long id;

	@Column(name = "trnumber")
	private String trNumber;
	
	@Column(name = "badgename")
	private String badgeName;
	
	@Column(name = "promoname")
	private String promoName;
	
	@Column(name = "expires")
	private Timestamp expires;

	public AnalyticsData() {
	}

	public AnalyticsData(String trNumber, String badgeName,String promoName,Timestamp expires) {
		this.trNumber=trNumber;
		this.badgeName=badgeName;
		this.promoName = promoName;
		this.expires = expires;
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getTrNumber() {
		return trNumber;
	}

	public void setTrNumber(String trNumber) {
		this.trNumber = trNumber;
	}

	public String getBadgeName() {
		return badgeName;
	}

	public void setBadgeName(String badgeName) {
		this.badgeName = badgeName;
	}

	public String getPromoName() {
		return promoName;
	}

	public void setPromoName(String promoName) {
		this.promoName = promoName;
	}

	public Timestamp getExpires() {
		return expires;
	}

	public void setExpires(Timestamp expires) {
		this.expires = expires;
	}

	@Override
	public String toString() {
		return "id: " + id + ", trnumber: " + trNumber + ", badgeName: " + badgeName+", promoName: "+promoName+", expires:"+expires;
	}
}
