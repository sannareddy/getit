package com.caesars.data.batch.domain.repo;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.caesars.data.batch.domain.model.AnalyticsData;
import com.caesars.data.batch.domain.model.PersonSource;

@Repository
public interface AnalyticsDataRepository extends PagingAndSortingRepository<AnalyticsData, Long> {

	//Add custom implementions methods if require here...
}