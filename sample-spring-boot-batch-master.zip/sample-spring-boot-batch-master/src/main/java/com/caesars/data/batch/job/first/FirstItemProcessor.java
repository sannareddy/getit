package com.caesars.data.batch.job.first;

import java.sql.Timestamp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.caesars.data.batch.domain.dto.PersonDTO;
import com.caesars.data.batch.domain.model.AnalyticsData;
import com.caesars.data.batch.domain.model.AnalyticsDedupedData;
import com.caesars.data.batch.domain.model.Person;
import com.caesars.data.batch.domain.model.PersonSource;
import com.caesars.data.batch.job.JobConstants;

@Component(JobConstants.FIRST_JOB_ITEM_PROCESSOR_ID)
public class FirstItemProcessor implements ItemProcessor<AnalyticsData, AnalyticsDedupedData> {

	private static final Logger LOGGER = LoggerFactory.getLogger(FirstItemProcessor.class);

	public AnalyticsDedupedData process(AnalyticsData item) throws Exception {

		final Long id=item.getId();
		final String trNumber = item.getTrNumber();
		final String badgeName = item.getBadgeName();
		final String promoName = item.getPromoName();
		final Timestamp expires = item.getExpires();
		final Timestamp dCreatedTimestamp=new Timestamp(System.currentTimeMillis());
        System.out.println("dCreatedTimestamp ==============> "+dCreatedTimestamp);

		final AnalyticsDedupedData transformed = new AnalyticsDedupedData(trNumber,badgeName,promoName,expires,dCreatedTimestamp);
		//transformed.setId(id);
				

		LOGGER.info("Converting (" + item + ") into (" + transformed + ")");

		return transformed;
	}
}