package com.caesars.data.batch.domain.repo;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.caesars.data.batch.domain.model.PersonSource;

@Repository
public interface PersonSourceRepository extends PagingAndSortingRepository<PersonSource, Long> {

}