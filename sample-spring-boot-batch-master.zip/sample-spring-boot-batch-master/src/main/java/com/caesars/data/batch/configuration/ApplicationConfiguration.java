package com.caesars.data.batch.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@ComponentScan(basePackages = { "com.caesars.data" })
@Configuration
public class ApplicationConfiguration {
}
