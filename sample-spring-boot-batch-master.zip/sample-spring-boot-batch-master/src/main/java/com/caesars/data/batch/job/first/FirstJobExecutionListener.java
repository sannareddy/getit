package com.caesars.data.batch.job.first;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.caesars.data.batch.domain.dto.PersonDTO;
import com.caesars.data.batch.domain.model.AnalyticsDedupedData;
import com.caesars.data.batch.job.JobConstants;

@Component(JobConstants.FIRST_JOB_EXECUTION_LISTENER_ID)
public class FirstJobExecutionListener extends JobExecutionListenerSupport {

	private static final Logger LOGGER = LoggerFactory.getLogger(FirstJobExecutionListener.class);

	private final JdbcTemplate jdbcTemplate;

	public FirstJobExecutionListener(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public void afterJob(JobExecution jobExecution) {

		if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
			LOGGER.info("!!! JOB FINISHED! Time to verify the results");

			List<AnalyticsDedupedData> results = jdbcTemplate.query("SELECT id,trNumber, badgeName,promoName,expires,d_Created_Timestamp FROM ANALYTICS_DEDUPED", new RowMapper<AnalyticsDedupedData>() {
				public AnalyticsDedupedData mapRow(ResultSet rs, int row) throws SQLException {
					Long id=	rs.getLong(1);
					String trNumber = rs.getString(2);
					String badgeName = rs.getString(3);
					String promoName = rs.getString(4);
					Timestamp expires = rs.getTimestamp(5);
					Timestamp dCreatedTimestamp = rs.getTimestamp(6);
					AnalyticsDedupedData obj=new AnalyticsDedupedData(trNumber,badgeName,promoName,expires,dCreatedTimestamp);
					obj.setId(id);
					return obj;
				}
			});

			int nbResults = ((results == null) ? 0 : results.size());
			LOGGER.info("Found {} entities in the database.", nbResults);
			if (results != null) {
				int index = 0;
				for (AnalyticsDedupedData analyticsDedupedData : results) {
					index++;
					LOGGER.info("{}/{}: Found <{}> in the database.", index, nbResults, analyticsDedupedData);
				}
			}
		}
	}
}
