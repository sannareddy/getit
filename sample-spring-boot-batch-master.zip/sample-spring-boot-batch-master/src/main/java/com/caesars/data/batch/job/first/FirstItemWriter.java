package com.caesars.data.batch.job.first;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

import com.caesars.data.batch.domain.model.AnalyticsDedupedData;
import com.caesars.data.batch.domain.model.Person;
import com.caesars.data.batch.job.JobConstants;

@Component(JobConstants.FIRST_JOB_ITEM_WRITER_ID)
public class FirstItemWriter implements ItemWriter<AnalyticsDedupedData> {

	private static final Logger LOGGER = LoggerFactory.getLogger(FirstItemWriter.class);

	@PersistenceContext
	protected EntityManager entityManager;

	
	public void write(List<? extends AnalyticsDedupedData> items) throws Exception {

		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("Writing to JPA with {} items.", items.size());
		}

		if (! items.isEmpty()) {

			long persistCount = 0;
			long mergeCount = 0;

			for (AnalyticsDedupedData item : items) {
				/*if (item.getId() == null) {
					entityManager.persist(item);
					persistCount++;
				} else {*/			
				//entityManager.createQuery("").getResultList();				
				
				//Record in database
				//AnalyticsDedupedData analyticsDedupedData=entityManager.find(AnalyticsDedupedData.class, new Long(item.getId()));
				
				List<AnalyticsDedupedData> analyticsDedupedData=
						entityManager
								.createQuery(
										"SELECT o FROM ANALYTICS_DEDUPED o WHERE UPPER(o.trNumber)=UPPER(:trNumber) and UPPER(o.badgeName)=UPPER(:badgeName)",
										AnalyticsDedupedData.class)
								.setParameter("trNumber", item.getTrNumber())
								.setParameter("badgeName", item.getBadgeName()).getResultList();
				
				if(analyticsDedupedData == null || analyticsDedupedData.size() == 0){
					entityManager.persist(item);
					persistCount++;
				}else{
					AnalyticsDedupedData firstAnalyticsDedupedData=analyticsDedupedData.get(0);
					if(firstAnalyticsDedupedData.getExpires().before(item.getExpires())){
						firstAnalyticsDedupedData.setExpires(item.getExpires());
						firstAnalyticsDedupedData.setdCreatedTimestamp(item.getdCreatedTimestamp());
						firstAnalyticsDedupedData.setPromoName(item.getPromoName());
						entityManager.merge(firstAnalyticsDedupedData);
						mergeCount++;
					}else{
						//Leave it.....
					}
				}					
				//}
			}
			entityManager.flush();
			entityManager.clear();

			if (LOGGER.isInfoEnabled()) {
				LOGGER.info("{} entities persisted.", persistCount);
				LOGGER.info("{} entities merged.", mergeCount);
			}
		}
	}
}
